package th.donut;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class DonutSMP extends JavaPlugin implements Listener, TabExecutor {

    // ---------- โครงสร้างข้อมูล ----------
    static class Gui implements InventoryHolder {
        final String type;
        Inventory inv;
        List<Order> orders = new ArrayList<>();
        Gui(String type) { this.type = type; }
        @Override public Inventory getInventory() { return inv; }
    }

    static class Order {
        final int id; final UUID owner; final Material mat; int left; final double price;
        Order(int id, UUID owner, Material mat, int left, double price) {
            this.id = id; this.owner = owner; this.mat = mat; this.left = left; this.price = price;
        }
    }

    private final Map<UUID, Double> money = new HashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final Map<UUID, Map<String, Integer>> claims = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private int nextOrderId = 1;
    private File dataFile;
    private YamlConfiguration data;

    // ---------- เปิด/ปิดปลั๊กอิน ----------
    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("shop", "sell", "order", "rtp", "sethome", "home", "delhome", "homes", "balance", "pay", "eco")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        Bukkit.getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(this::updateBoard), 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
        Bukkit.getOnlinePlayers().forEach(this::setupBoard);
    }

    @Override
    public void onDisable() { saveData(); }

    // ---------- Utility ----------
    String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    void msg(CommandSender s, String m) { s.sendMessage(c(getConfig().getString("prefix", "") + m)); }

    double bal(UUID id) { return money.getOrDefault(id, 0.0); }

    void add(UUID id, double amt) { money.put(id, Math.max(0, bal(id) + amt)); }

    boolean take(UUID id, double amt) {
        if (bal(id) < amt) return false;
        money.put(id, bal(id) - amt);
        return true;
    }

    static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        if (i == 0) return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
        String s = String.format(Locale.US, "%.1f", v);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    static String fmtTime(long sec) {
        long d = sec / 86400, h = sec % 86400 / 3600, m = sec % 3600 / 60;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }

    double parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) mul = 1e3;
            else if (s.endsWith("m")) mul = 1e6;
            else if (s.endsWith("b")) mul = 1e9;
            if (mul != 1) s = s.substring(0, s.length() - 1);
            double v = Double.parseDouble(s) * mul;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? -1 : v;
        } catch (Exception e) { return -1; }
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    // ---------- เก็บข้อมูล ----------
    void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection m = data.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection os = data.getConfigurationSection("orders");
        if (os != null) for (String k : os.getKeys(false)) {
            ConfigurationSection s = os.getConfigurationSection(k);
            Material mat = Material.matchMaterial(s.getString("item", ""));
            if (mat == null) continue;
            int id = Integer.parseInt(k);
            orders.add(new Order(id, UUID.fromString(s.getString("owner")), mat, s.getInt("left"), s.getDouble("price")));
            nextOrderId = Math.max(nextOrderId, id + 1);
        }
        ConfigurationSection cs = data.getConfigurationSection("claims");
        if (cs != null) for (String owner : cs.getKeys(false)) {
            Map<String, Integer> map = new HashMap<>();
            ConfigurationSection items = cs.getConfigurationSection(owner);
            for (String mat : items.getKeys(false)) map.put(mat, items.getInt(mat));
            claims.put(UUID.fromString(owner), map);
        }
    }

    void saveData() {
        data.set("money", null);
        money.forEach((k, v) -> data.set("money." + k, v));
        data.set("orders", null);
        for (Order o : orders) {
            String p = "orders." + o.id + ".";
            data.set(p + "owner", o.owner.toString());
            data.set(p + "item", o.mat.name());
            data.set(p + "left", o.left);
            data.set(p + "price", o.price);
        }
        data.set("claims", null);
        claims.forEach((k, map) -> map.forEach((mat, n) -> data.set("claims." + k + "." + mat, n)));
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    // ---------- Scoreboard ----------
    void setupBoard(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", Criteria.DUMMY, c(getConfig().getString("scoreboard.title", "DONUT SMP")));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        int n = Math.min(15, getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = "§" + Integer.toHexString(i) + "§r";
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        updateBoard(p);
    }

    void updateBoard(Player p) {
        Scoreboard sb = p.getScoreboard();
        if (sb.getObjective("donut") == null) { setupBoard(p); return; }
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        for (int i = 0; i < Math.min(15, lines.size()); i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String line = lines.get(i)
                    .replace("{money}", fmt(bal(p.getUniqueId())))
                    .replace("{kills}", String.valueOf(p.getStatistic(Statistic.PLAYER_KILLS)))
                    .replace("{deaths}", String.valueOf(p.getStatistic(Statistic.DEATHS)))
                    .replace("{playtime}", fmtTime(p.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20L))
                    .replace("{player}", p.getName())
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()));
            t.setPrefix(c(line));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!money.containsKey(p.getUniqueId())) money.put(p.getUniqueId(), getConfig().getDouble("start-money", 0));
        setupBoard(p);
    }

    // ---------- คำสั่ง ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);

        if (n.equals("eco")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length < 3) { msg(s, "&e/eco <give|set|take> <player> <amount>"); return true; }
            OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
            double amt = parseAmount(a[2]);
            if (amt < 0) { msg(s, "&cจำนวนไม่ถูกต้อง"); return true; }
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "give" -> add(t.getUniqueId(), amt);
                case "take" -> add(t.getUniqueId(), -amt);
                case "set" -> money.put(t.getUniqueId(), amt);
                default -> { msg(s, "&cใช้ give/set/take"); return true; }
            }
            msg(s, "&aเงินของ " + a[1] + " ตอนนี้ $" + fmt(bal(t.getUniqueId())));
            return true;
        }

        if (!(s instanceof Player p)) { s.sendMessage("เฉพาะผู้เล่นเท่านั้น"); return true; }

        switch (n) {
            case "shop" -> openShop(p);
            case "sell" -> openSell(p);
            case "order" -> orderCmd(p, a);
            case "rtp" -> rtp(p);
            case "balance" -> msg(p, "&eเงินของคุณ: &a$" + fmt(bal(p.getUniqueId())));
            case "pay" -> pay(p, a);
            case "sethome" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                String base = "homes." + p.getUniqueId();
                ConfigurationSection hs = data.getConfigurationSection(base);
                int count = hs == null ? 0 : hs.getKeys(false).size();
                boolean exists = hs != null && hs.contains(name);
                if (!exists && count >= getConfig().getInt("homes.max", 3)) { msg(p, "&cคุณตั้งบ้านได้สูงสุด " + getConfig().getInt("homes.max", 3) + " หลัง"); return true; }
                data.set(base + "." + name, p.getLocation());
                msg(p, "&aตั้งบ้าน &e" + name + " &aแล้ว");
            }
            case "home" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                Location l = data.getLocation("homes." + p.getUniqueId() + "." + name);
                if (l == null) { msg(p, "&cไม่พบบ้านชื่อ " + name); return true; }
                p.teleportAsync(l);
                msg(p, "&aวาปไปบ้าน &e" + name);
            }
            case "delhome" -> {
                if (a.length < 1) { msg(p, "&e/delhome <name>"); return true; }
                String path = "homes." + p.getUniqueId() + "." + a[0].toLowerCase(Locale.ROOT);
                if (!data.contains(path)) { msg(p, "&cไม่พบบ้านนี้"); return true; }
                data.set(path, null);
                msg(p, "&aลบบ้านแล้ว");
            }
            case "homes" -> {
                ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
                msg(p, "&eบ้านของคุณ: &f" + (hs == null || hs.getKeys(false).isEmpty() ? "ไม่มี" : String.join(", ", hs.getKeys(false))));
            }
        }
        return true;
    }

    void pay(Player p, String[] a) {
        if (a.length < 2) { msg(p, "&e/pay <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        double amt = parseAmount(a[1]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (amt <= 0) { msg(p, "&cจำนวนไม่ถูกต้อง"); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cเงินไม่พอ"); return; }
        add(t.getUniqueId(), amt);
        msg(p, "&aโอน $" + fmt(amt) + " ให้ " + t.getName());
        msg(t, "&aได้รับ $" + fmt(amt) + " จาก " + p.getName());
    }

    // ---------- /shop ----------
    void openShop(Player p) {
        Gui g = new Gui("shop");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-title")));
        ConfigurationSection s = getConfig().getConfigurationSection("shop");
        if (s != null) for (String key : s.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            if (m == null || !m.isItem()) continue;
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            meta.setLore(List.of(c("&7ราคา: &a$" + fmt(s.getDouble(key)) + " &7/ชิ้น"), c("&eคลิกซ้าย = ซื้อ 1"), c("&eShift+คลิก = ซื้อ 64")));
            it.setItemMeta(meta);
            g.inv.addItem(it);
        }
        p.openInventory(g.inv);
    }

    // ---------- /sell ----------
    void openSell(Player p) {
        Gui g = new Gui("sell");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("sell-title")));
        p.openInventory(g.inv);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g) || !g.type.equals("sell")) return;
        Player p = (Player) e.getPlayer();
        double total = 0;
        int sold = 0;
        for (ItemStack it : e.getInventory().getContents()) {
            if (it == null || it.getType().isAir()) continue;
            double price = getConfig().getDouble("sell." + it.getType().name(), 0);
            if (price > 0) { total += price * it.getAmount(); sold += it.getAmount(); }
            else give(p, it);
        }
        e.getInventory().clear();
        if (total > 0) {
            add(p.getUniqueId(), total);
            msg(p, "&aขาย " + sold + " ชิ้น ได้เงิน &e$" + fmt(total));
        }
    }

    // ---------- /order ----------
    void orderCmd(Player p, String[] a) {
        if (a.length == 0) { openOrders(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 4) { msg(p, "&e/order create <item> <amount> <price ต่อชิ้น>"); return; }
                Material m = Material.matchMaterial(a[1]);
                int amt;
                try { amt = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { amt = -1; }
                double price = parseAmount(a[3]);
                if (m == null || !m.isItem() || amt <= 0 || price <= 0) { msg(p, "&cข้อมูลไม่ถูกต้อง"); return; }
                double cost = amt * price;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, amt, price));
                msg(p, "&aสร้างออเดอร์รับซื้อ " + m.name() + " x" + amt + " ราคา $" + fmt(price) + "/ชิ้น");
            }
            case "claim" -> {
                Map<String, Integer> map = claims.remove(p.getUniqueId());
                if (map == null || map.isEmpty()) { msg(p, "&cไม่มีของให้รับ"); return; }
                map.forEach((mat, n) -> {
                    Material m = Material.matchMaterial(mat);
                    if (m == null) return;
                    int left = n;
                    while (left > 0) {
                        int st = Math.min(left, m.getMaxStackSize());
                        give(p, new ItemStack(m, st));
                        left -= st;
                    }
                });
                msg(p, "&aรับของจากออเดอร์แล้ว");
            }
            default -> openOrders(p);
        }
    }

    void openOrders(Player p) {
        Gui g = new Gui("orders");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("order-title")));
        for (Order o : orders) {
            if (g.orders.size() >= 54) break;
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            String owner = Optional.ofNullable(Bukkit.getOfflinePlayer(o.owner).getName()).orElse("?");
            List<String> lore = new ArrayList<>(List.of(
                    c("&7ผู้สั่ง: &f" + owner),
                    c("&7ต้องการอีก: &f" + o.left),
                    c("&7ราคาต่อชิ้น: &a$" + fmt(o.price)),
                    c("&aคลิกซ้าย = ส่งของให้ออเดอร์นี้")));
            if (o.owner.equals(p.getUniqueId())) lore.add(c("&cคลิกขวา = ยกเลิก (คืนเงิน)"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        p.openInventory(g.inv);
    }

    void fillOrder(Player p, Order o) {
        if (o.owner.equals(p.getUniqueId())) { msg(p, "&cส่งของให้ออเดอร์ตัวเองไม่ได้"); return; }
        ItemStack[] cs = p.getInventory().getStorageContents();
        int have = 0;
        for (ItemStack it : cs) if (it != null && it.getType() == o.mat && !it.hasItemMeta()) have += it.getAmount();
        int n = Math.min(have, o.left);
        if (n <= 0) { msg(p, "&cคุณไม่มี " + o.mat.name()); return; }
        int rem = n;
        for (int i = 0; i < cs.length && rem > 0; i++) {
            ItemStack it = cs[i];
            if (it == null || it.getType() != o.mat || it.hasItemMeta()) continue;
            int t = Math.min(rem, it.getAmount());
            if (t == it.getAmount()) cs[i] = null; else it.setAmount(it.getAmount() - t);
            rem -= t;
        }
        p.getInventory().setStorageContents(cs);
        double pay = n * o.price;
        add(p.getUniqueId(), pay);
        claims.computeIfAbsent(o.owner, k -> new HashMap<>()).merge(o.mat.name(), n, Integer::sum);
        o.left -= n;
        if (o.left <= 0) orders.remove(o);
        msg(p, "&aส่ง " + n + " ชิ้น ได้เงิน &e$" + fmt(pay));
        Player owner = Bukkit.getPlayer(o.owner);
        if (owner != null) msg(owner, "&aมีคนส่ง " + o.mat.name() + " x" + n + " ให้ออเดอร์ของคุณ! พิมพ์ &e/order claim");
    }

    // ---------- คลิก GUI ----------
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) return; // ให้วางของได้อิสระ
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType().isAir()) return;
        Player p = (Player) e.getWhoClicked();

        if (g.type.equals("shop")) {
            int amt = e.isShiftClick() ? 64 : 1;
            double price = getConfig().getDouble("shop." + it.getType().name(), -1);
            if (price < 0) return;
            double total = price * amt;
            if (!take(p.getUniqueId(), total)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(total) + ")"); return; }
            give(p, new ItemStack(it.getType(), amt));
            msg(p, "&aซื้อ " + it.getType().name() + " x" + amt + " ราคา $" + fmt(total));
        } else if (g.type.equals("orders")) {
            int slot = e.getSlot();
            if (slot >= g.orders.size()) return;
            Order o = g.orders.get(slot);
            if (!orders.contains(o)) { openOrders(p); return; }
            if (e.isRightClick() && o.owner.equals(p.getUniqueId())) {
                orders.remove(o);
                add(p.getUniqueId(), o.left * o.price);
                msg(p, "&aยกเลิกออเดอร์ คืนเงิน $" + fmt(o.left * o.price));
            } else if (e.isLeftClick()) {
                fillOrder(p, o);
            }
            openOrders(p);
        }
    }

    // ---------- /rtp ----------
    void rtp(Player p) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("rtp.cooldown", 10) * 1000;
        Long last = rtpCooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { msg(p, "&cรออีก " + ((cd - (now - last)) / 1000 + 1) + " วินาที"); return; }
        World w = p.getWorld();
        if (w.getEnvironment() != World.Environment.NORMAL) { msg(p, "&cใช้ /rtp ได้เฉพาะโอเวอร์เวิลด์"); return; }
        rtpCooldown.put(p.getUniqueId(), now);
        msg(p, "&eกำลังสุ่มตำแหน่ง...");
        tryRtp(p, w, 0);
    }

    void tryRtp(Player p, World w, int tries) {
        if (tries >= 15) { msg(p, "&cหาตำแหน่งปลอดภัยไม่ได้ ลองใหม่อีกครั้ง"); rtpCooldown.remove(p.getUniqueId()); return; }
        Location ctr = w.getWorldBorder().getCenter();
        int max = (int) Math.min(getConfig().getInt("rtp.max", 5000), w.getWorldBorder().getSize() / 2 - 16);
        int min = Math.min(getConfig().getInt("rtp.min", 500), max / 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (ctr.getX() + Math.cos(ang) * dist);
        int z = (int) (ctr.getZ() + Math.sin(ang) * dist);
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            int y = w.getHighestBlockYAt(x, z);
            Block b = w.getBlockAt(x, y, z);
            if (!isSafe(b)) { tryRtp(p, w, tries + 1); return; }
            p.teleportAsync(new Location(w, x + 0.5, y + 1, z + 0.5)).thenAccept(ok -> {
                if (ok) msg(p, "&aวาปแล้ว! &7X: " + x + " Z: " + z);
            });
        }));
    }

    boolean isSafe(Block b) {
        Material t = b.getType();
        if (!t.isSolid() || Tag.LEAVES.isTagged(t)) return false;
        switch (t) {
            case MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE, POWDER_SNOW, SWEET_BERRY_BUSH, WITHER_ROSE -> { return false; }
            default -> { }
        }
        return b.getRelative(0, 1, 0).isPassable() && b.getRelative(0, 2, 0).isPassable()
                && !b.getRelative(0, 1, 0).isLiquid();
    }

    // ---------- Tab complete ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) {
            ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
            return hs == null ? List.of() : hs.getKeys(false).stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (n.equals("order")) {
            if (a.length == 1) return List.of("create", "claim");
            if (a.length == 2 && a[0].equalsIgnoreCase("create"))
                return Arrays.stream(Material.values()).filter(Material::isItem).map(m -> m.name().toLowerCase(Locale.ROOT))
                        .filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        if (n.equals("eco") && a.length == 1) return List.of("give", "take", "set");
        return List.of();
    }
}
